package com.project.VehicleManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
